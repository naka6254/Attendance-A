class StaticPagesController < ApplicationController
  def top
  end
end
